
CREATE PROCEDURE [dbo].[uspGetEmployeeOrdersCount]
    @ShipMethods NVARCHAR(MAX)
AS
BEGIN
	DECLARE @Query NVARCHAR(MAX)
	SET @Query =
	'SELECT * 
	FROM
	(
		SELECT [POH].[EmployeeID], [SM].[Name], COUNT([Name])
		FROM [Purchasing].[PurchaseOrderHeader] AS [POH]
		INNER JOIN [Purchasing].[ShipMethod] AS [SM]
		ON [POH].[ShipMethodID] = [SM].[ShipMethodID]
		GROUP BY [POH].[EmployeeID], [SM].[Name]
	) AS [T]
	PIVOT
	(
		COUNT([T].[Name])
		FOR [Name] IN (' + @ShipMethods + ')
	) AS [P]
	ORDER BY [P].[EmployeeID]'
	print @Query 
	EXECUTE (@Query);
END;
