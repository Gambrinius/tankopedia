
CREATE FUNCTION [dbo].[ufnGetProductModelTotalPrice](@ProductModelID int)
RETURNS money 
AS 
BEGIN
    RETURN (SELECT SUM([PP].[ListPrice]) 
			FROM [Production].[Product] [PP] 
			WHERE [PP].[ProductModelID] = @ProductModelID)
END;
