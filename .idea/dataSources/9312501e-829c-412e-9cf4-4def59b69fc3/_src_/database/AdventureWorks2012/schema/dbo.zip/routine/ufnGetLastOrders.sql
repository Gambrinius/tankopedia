
CREATE FUNCTION [dbo].[ufnGetLastOrders](@CustomerID int)
RETURNS TABLE 
AS 
    RETURN (SELECT TOP 2 *
			FROM [Sales].[SalesOrderHeader] 
			WHERE CustomerID = @CustomerID 
			ORDER BY [OrderDate] DESC)

